function setup() {
  createCanvas(1920, 1080);
}

function draw() {
  background(220);
}